require.config({
    paths: {
        'webix': '../libs/webix/codebase/webix',
        'filemanager': '../libs/webix/codebase/filemanager',
    },
    shim: {
        "filemanager": {
            deps: ["webix"],
            exports: "filemanager"
        }
    }
});